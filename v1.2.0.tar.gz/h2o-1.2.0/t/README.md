The tests are numbered using the following rule.

- 00 - unit tests
- 10 - module-level end-to-end tests
- (library level tests may go in here)
- 40 - protocol tests
- 50 - end-to-end tests
- (issue tests may go in here)
- 90 - author tests?
